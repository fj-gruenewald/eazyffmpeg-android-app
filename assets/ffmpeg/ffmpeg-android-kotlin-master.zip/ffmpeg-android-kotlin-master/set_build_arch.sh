#!/bin/bash

SUPPORTED_ARCHITECTURES=(armeabi-v7a x86)
